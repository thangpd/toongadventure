<?php

include_once SETSAIL_MEMBERSHIP_SHORTCODES_PATH . '/login/functions.php';
include_once SETSAIL_MEMBERSHIP_SHORTCODES_PATH . '/login/login.php';