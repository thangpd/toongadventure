<a href="javascript:void(0)" class="qodef-membership-item-favorites qodef-icon-only" data-item-id="<?php echo esc_attr($item_id); ?>">
    <i class="qodef-favorites-icon <?php echo esc_attr($icon); ?>" aria-hidden="true"></i>
</a>