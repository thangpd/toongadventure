<?php

include_once SETSAIL_MEMBERSHIP_SHORTCODES_PATH . '/register/functions.php';
include_once SETSAIL_MEMBERSHIP_SHORTCODES_PATH . '/register/register.php';