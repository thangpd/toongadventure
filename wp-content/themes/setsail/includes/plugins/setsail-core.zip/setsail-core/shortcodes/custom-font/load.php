<?php

include_once SETSAIL_CORE_SHORTCODES_PATH . '/custom-font/functions.php';
include_once SETSAIL_CORE_SHORTCODES_PATH . '/custom-font/custom-font.php';