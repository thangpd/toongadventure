<div class="qodef-comment-input-text">
	<span class="qodef-comment-icon qodef-comment-message-icon icon_chat"></span>
	<textarea id="comment" placeholder="<?php esc_attr_e( 'Comment', 'setsail-core' ); ?>" name="comment" cols="45" rows="6" aria-required="true"></textarea>
</div>
