<?php

include_once SETSAIL_CORE_CPT_PATH . '/testimonials/testimonials-register.php';
include_once SETSAIL_CORE_CPT_PATH . '/testimonials/helper-functions.php';