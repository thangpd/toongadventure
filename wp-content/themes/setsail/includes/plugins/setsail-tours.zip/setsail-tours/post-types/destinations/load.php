<?php

include_once SETSAIL_TOURS_CPT_PATH . '/destinations/destinations-register.php';
include_once SETSAIL_TOURS_CPT_PATH . '/destinations/helper-functions.php';