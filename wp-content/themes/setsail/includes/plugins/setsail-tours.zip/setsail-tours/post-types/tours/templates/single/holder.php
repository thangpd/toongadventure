<div class="qodef-container">
	<div class="qodef-container-inner clearfix <?php echo esc_attr($holder_class) ?>">
		<?php echo setsail_tours_get_tour_module_template_part('single/single-item', 'tours', 'templates', '', $params); ?>
	</div>
</div>